# Kaartensite

Een Next.js project om AI-gegeneerde kaarten te maken en te bestellen.

## Gebruik

- `npm install`
- `npm run dev`
- Voeg je API sleutels toe in `.env.local`